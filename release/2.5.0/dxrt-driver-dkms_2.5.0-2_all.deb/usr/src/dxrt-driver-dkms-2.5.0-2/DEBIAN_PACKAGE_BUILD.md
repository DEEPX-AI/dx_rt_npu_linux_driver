# Debian Package Build Process

DeepX NPU Driver DKMS 패키지 빌드 및 배포를 위한 프로세스 가이드입니다.

## Overview

- **Package Name**: `dxrt-driver-dkms`
- **Package Type**: DKMS (Dynamic Kernel Module Support)
- **Build Tool**: `dpkg-buildpackage`
- **Version Source**: `release.ver` file
- **Output Location**: `release/${VERSION}/`

## Directory Structure

```
dx_rt_npu_linux_driver/
├── release.ver                          # Version source (e.g., "v2.1.0")
├── debian/                              # Debian package configuration
│   ├── changelog                        # Package changelog (MUST UPDATE)
│   ├── control                          # Package metadata
│   ├── rules                            # Build rules
│   ├── compat                           # Debhelper compatibility level
│   ├── dxrt-driver-dkms.install         # File installation rules
│   ├── postinst                         # Post-installation script
│   └── prerm                            # Pre-removal script
├── dkms.conf                            # DKMS configuration
├── modules/                             # Source code
│   ├── build.sh                         # Build wrapper script
│   └── scripts/
│       └── debian_builder.sh            # Debian build functions
└── release/                             # Built packages
    ├── 2.1.0/
    │   └── dxrt-driver-dkms_2.1.0-2_all.deb
    └── latest -> 2.1.0/
```

## Build Process Flow

```
1. Read version from release.ver
2. Validate debian/changelog
3. Run dpkg-buildpackage
4. Move .deb to release/${VERSION}/
5. Update 'latest' symlink
6. Cleanup build artifacts
```

## Prerequisites

### System Requirements

```bash
# Ubuntu/Debian
sudo apt-get install -y \
    dpkg-dev \
    debhelper \
    dkms \
    build-essential

# Check versions
dpkg-buildpackage --version
dkms --version
```

### File Checklist

Before building, ensure these files are properly configured:

- [ ] `release.ver` - Contains correct version (e.g., `v2.1.0`)
- [ ] `debian/changelog` - Updated with new version entry
- [ ] `debian/control` - Correct maintainer and dependencies
- [ ] `dkms.conf` - Correct PACKAGE_VERSION

## Manual Build Steps

### Step 1: Update Version

Edit `release.ver`:
```bash
echo "v2.1.0" > release.ver
```

### Step 2: Update Changelog

**CRITICAL**: `debian/changelog` MUST be updated before every build.

#### Format:
```
dxrt-driver-dkms (VERSION-REVISION) DISTRIBUTION; urgency=URGENCY

  * Change description line 1
  * Change description line 2

 -- Maintainer Name <email@example.com>  DATE
```

#### Example:
```bash
# Edit debian/changelog
vim debian/changelog
```

Add new entry at the TOP:
```
dxrt-driver-dkms (2.1.0-2) unstable; urgency=medium

  * Add sleep/resched in dxrt_polling_ack to avoid soft lockups
  * Optimized PCIe DMA performance
  * Compatible with DX-RT SDK v3.2.1+

 -- An Taegyun <atg@deepx.ai>  Mon, 10 Feb 2026 10:00:00 +0900
```

**Date Format**: Use `date -R` to generate RFC 2822 format:
```bash
date -R
# Mon, 10 Feb 2026 10:00:00 +0900
```

### Step 3: Build Package

```bash
cd modules/
./build.sh -c debian-package
```

**Build Output:**
```
*** Building Debian Package ***

-> Checking Debian build prerequisites...
✓ Prerequisites checked
Debian package version: 2.1.0-2
✓ Changelog is up-to-date with version 2.1.0-2
-> Building in: /path/to/dx_rt_npu_linux_driver
-> Running dpkg-buildpackage...
   This may take a few minutes...

✓ Package built successfully
-> Found package: dxrt-driver-dkms_2.1.0-2_all.deb
-> Moving to release/2.1.0/
✓ Package installed to release/2.1.0/
✓ Symlink 'latest' -> 2.1.0
-> Cleaning up build artifacts...
✓ Build artifacts cleaned up

*** Debian Package Build Completed ***

  Package: dxrt-driver-dkms
  Version: 2.1.0-2
  Location: release/2.1.0/
```

### Step 4: Verify Package

```bash
# Check file exists
ls -lh release/2.1.0/dxrt-driver-dkms_2.1.0-2_all.deb

# Inspect package contents
dpkg-deb -c release/2.1.0/dxrt-driver-dkms_2.1.0-2_all.deb

# Check package info
dpkg-deb -I release/2.1.0/dxrt-driver-dkms_2.1.0-2_all.deb
```

## External User Installation

외부 고객에게 `.deb` 파일만 전달하여 설치하는 방법입니다.

### Online Environment (인터넷 연결 가능)

```bash
# .deb 파일 경로 앞에 반드시 "./" 또는 절대경로 사용
sudo apt-get install ./dxrt-driver-dkms_2.1.0-2_all.deb
```

`apt-get install`이 `dkms`, `linux-headers`, `build-essential` 등 필요한 의존성을 자동으로 설치합니다.

> **주의**: `apt-get install dxrt-driver-dkms_2.1.0-2_all.deb` (경로 없이) 사용 시 APT 리포에서 패키지명으로 검색하여 `Unable to locate package` 에러가 발생합니다. 반드시 `./` 또는 절대경로를 사용하세요.

### Offline Environment (인터넷 없음)

의존성 패키지를 사전에 설치한 후 진행합니다:

```bash
# 1. 사전에 필요한 패키지 설치 (별도 경로로 확보)
sudo dpkg -i dkms_*.deb
sudo dpkg -i linux-headers-$(uname -r)_*.deb
sudo dpkg -i build-essential_*.deb

# 2. 드라이버 패키지 설치
sudo dpkg -i dxrt-driver-dkms_2.1.0-2_all.deb
```

### Required Dependencies

| 패키지 | 용도 |
|--------|------|
| `dkms` | DKMS 프레임워크 (커널 업데이트 시 자동 빌드) |
| `linux-headers-$(uname -r)` | 현재 커널에 맞는 헤더 (DKMS 빌드에 필수) |
| `build-essential` | gcc, make 등 빌드 도구 |

> **주의 (--no-install-recommends 환경)**: `apt-get`에 `--no-install-recommends` 옵션을 사용하거나
> 해당 설정이 시스템 전체에 적용된 환경에서는 `linux-headers`가 자동 설치되지 않습니다.
> 이 경우 반드시 수동으로 커널 헤더를 먼저 설치하세요:
> ```bash
> sudo apt-get install -y linux-headers-$(uname -r)
> ```

### Troubleshooting

**`dependency problems - leaving unconfigured` 에러:**
```bash
# 의존성 확인
sudo apt-get install -y dkms linux-headers-$(uname -r) build-essential

# 재설치
sudo apt-get install -y ./dxrt-driver-dkms_*.deb
```

**`Unable to locate package` 에러:**
```bash
# "./" 접두사를 붙여서 로컬 파일임을 명시
sudo apt-get install ./dxrt-driver-dkms_2.1.0-2_all.deb
#                     ^^ 이 부분 필수
```