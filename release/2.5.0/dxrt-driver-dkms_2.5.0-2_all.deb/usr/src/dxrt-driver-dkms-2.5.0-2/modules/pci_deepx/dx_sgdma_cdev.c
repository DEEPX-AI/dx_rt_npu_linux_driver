// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (c) 2022-2023 DeepX, Inc. and/or its affiliates.
 * DeepX eDMA PCIe driver
 *
 * Author: Taegyun An <atg@deepx.ai>
 */

#include <linux/errno.h>
#include <linux/unistd.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/slab.h>
#include <linux/device.h>
#include <linux/cdev.h>

#include <linux/scatterlist.h>
#include <asm/cacheflush.h>
#include <linux/delay.h>

#include "dx_sgdma_cdev.h"
#include "dx_lib.h"
#include "dw-edma-thread.h"
#include "dw-edma-v0-core.h"
#include "dx_util.h"

#define IOCTL_PRINT 1

int dx_sgdma_cdev_open(struct inode *inode, struct file *filp);
int dx_sgdma_cdev_release(struct inode *inode, struct file *filp);
ssize_t dx_sgdma_cdev_read(struct file *filp, char __user *buf, size_t count, loff_t *pos);
ssize_t dx_sgdma_cdev_write(struct file *filp, const char __user *buf, size_t count, loff_t *pos);
long dx_sgdma_cdev_ioctl(struct file *filp, unsigned int cmd, unsigned long data);
static loff_t dx_sgdma_cdev_llseek(struct file *file, loff_t off, int whence);

/*
 * character device file operations for SG DMA engine
 */
static loff_t dx_sgdma_cdev_llseek(struct file *file, loff_t off, int whence)
{
	loff_t newpos = 0;

	switch (whence) {
	case 0: /* SEEK_SET */
		newpos = off;
		break;
	case 1: /* SEEK_CUR */
		newpos = file->f_pos + off;
		break;
	case 2: /* SEEK_END, @TODO should work from end of address space */
		newpos = UINT_MAX + off;
		break;
	default: /* can't happen */
		return -EINVAL;
	}
	if (newpos < 0)
		return -EINVAL;
	file->f_pos = newpos;
	dbg_sg("%s: pos=0x%llx\n", __func__, (signed long long)newpos);

#if 0
	pr_err("0x%p, off %lld, whence %d -> pos %lld.\n",
		file, (signed long long)off, whence, (signed long long)off);
#endif

	return newpos;
}

/* when open() is called */
int dx_sgdma_cdev_open(struct inode *inode, struct file *filp) {
	struct dx_dma_cdev *xcdev;
	struct dw_edma *dw;
	unsigned long flags;
	int ret;
	u16 h2c_max;

	ret = char_open(inode, filp);
	if (ret)
		return ret;
	xcdev = (struct dx_dma_cdev *)filp->private_data;
	dw = xcdev->xpdev->dw;
	if (atomic_read(&dw->dev_state) == DX_DEV_REMOVING)
		return -ENODEV;
	if (atomic_read(&dw->dev_state) != DX_DEV_LIVE ||
	    atomic_read(&dw->link_state) != DX_LINK_UP ||
	    atomic_read(&dw->background_recovery_paused)) {
		pr_warn_ratelimited("[%s] dev %d: DMA cdev open rejected while not ready (dev_state=%d link_state=%d paused=%d)\n",
			__func__, dw->idx, atomic_read(&dw->dev_state),
			atomic_read(&dw->link_state),
			atomic_read(&dw->background_recovery_paused));
		return -EAGAIN;
	}

	spin_lock_irqsave(&xcdev->lock, flags);
	xcdev->f_count++;
	spin_unlock_irqrestore(&xcdev->lock, flags);

	dbg_sg("[%s][%s][%s] Device_#%d NPU_#%d called!(count:%d)\n", __func__,
		!xcdev->write ? "W" : "R",
		xcdev->sys_device->kobj.name,
		dw->idx, xcdev->npu_id,
		xcdev->f_count);
	/* TODO - Check device busy */

	/* DMA Channel allocation */
	if (xcdev->write) {
		if (xcdev->npu_id >= dw->wr_ch_cnt) {
			pr_err("[%s] dev %d: C2H channel %d is not available (valid: 0-%d)\n",
				__func__, dw->idx, xcdev->npu_id, dw->wr_ch_cnt - 1);
			ret = -ENODEV;
			goto err_open;
		}
		ret = dw_edma_dma_allocation(dw->rd_dma_id, xcdev->npu_id,
					     &dw->wr_dma_chan[xcdev->npu_id]);
	} else {
		h2c_max = min_t(u16, dw->rd_ch_cnt, DX_H2C_DATA_CH_CNT);
		if (xcdev->npu_id >= h2c_max) {
			pr_err("[%s] dev %d: H2C channel %d is helper-reserved (valid data: 0-%d)\n",
				__func__, dw->idx, xcdev->npu_id, h2c_max - 1);
			ret = -ENODEV;
			goto err_open;
		}
		ret = dw_edma_dma_allocation(dw->wr_dma_id, xcdev->npu_id,
					     &dw->rd_dma_chan[xcdev->npu_id]);
	}
	if (ret)
		goto err_open;

	return 0;

err_open:
	spin_lock_irqsave(&xcdev->lock, flags);
	xcdev->f_count--;
	spin_unlock_irqrestore(&xcdev->lock, flags);
	return ret;
}

/* when last close() is called */
int dx_sgdma_cdev_release(struct inode *inode, struct file *filp) {
	struct dx_dma_cdev *xcdev = (struct dx_dma_cdev *)filp->private_data;
	struct dw_edma *dw = xcdev->xpdev->dw;
	unsigned long flags;
	int count;

	spin_lock_irqsave(&xcdev->lock, flags);
	xcdev->f_count--;
	count = xcdev->f_count;
	spin_unlock_irqrestore(&xcdev->lock, flags);

	dbg_sg("[%s][%s][%s] Device_#%d NPU_#%d called!(count:%d)\n", __func__,
		!xcdev->write ? "W" : "R",
		xcdev->sys_device->kobj.name,
		dw->idx, xcdev->npu_id,
		count);

	if (count == 0 && dw->ref_count == 0) {
		pr_debug("[%s] dev %d: last cdev close (no Service), releasing DMA channel npu_id=%d\n",
			__func__, dw->idx, xcdev->npu_id);
		if (xcdev->write)
			dw_edma_dma_deallocation(&dw->wr_dma_chan[xcdev->npu_id]);
		else
			dw_edma_dma_deallocation(&dw->rd_dma_chan[xcdev->npu_id]);
	}

	return 0;
}

long dx_sgdma_cdev_ioctl(struct file *filp, unsigned int cmd, unsigned long data) {
	switch (cmd) {
	case IOCTL_PRINT:
		printk(KERN_ALERT "[%s] IOCTL_PRINT called!", __func__);
		break;
	default:
		printk(KERN_ALERT "[%s] unknown command!", __func__);
		break;
	}

	return 0;
}

/* Copy userspace buffer to kernel buffer  */
ssize_t dx_sgdma_cdev_write(struct file *filp, const char __user *buf, size_t count, loff_t *pos) {
	struct dx_dma_cdev *xcdev = (struct dx_dma_cdev *)filp->private_data;
	struct dw_edma *dw = xcdev->xpdev->dw;
	size_t ret;

	ret = dx_sgdma_write_user(dw, buf, (u64)*pos, count, xcdev->npu_id, false);

	return ret;
}

/* copy kernel buffer to userspace buffer, saved by write */
ssize_t dx_sgdma_cdev_read(struct file *filp, char __user *buf, size_t count, loff_t *pos) {
	struct dx_dma_cdev *xcdev = (struct dx_dma_cdev *)filp->private_data;
	struct dw_edma *dw = xcdev->xpdev->dw;
	size_t ret;

	ret = dx_sgdma_read_user(dw, buf, (u64)*pos, count, xcdev->npu_id);

	return ret;
}

static const struct file_operations sgdma_fops = {
  .owner           = THIS_MODULE,
  .read            = dx_sgdma_cdev_read,
  .write           = dx_sgdma_cdev_write,
  .open            = dx_sgdma_cdev_open,
  .release         = dx_sgdma_cdev_release,
  .unlocked_ioctl  = dx_sgdma_cdev_ioctl,
  .llseek          = dx_sgdma_cdev_llseek,
};

void dx_cdev_sgdma_init(struct dx_dma_cdev *xcdev)
{
	cdev_init(&xcdev->cdev, &sgdma_fops);
}
