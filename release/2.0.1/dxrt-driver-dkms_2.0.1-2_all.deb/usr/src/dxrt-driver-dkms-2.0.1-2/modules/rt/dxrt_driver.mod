/home/atg/m1/dx_rt_npu_linux_driver/modules/rt/dxrt_drv.o /home/atg/m1/dx_rt_npu_linux_driver/modules/rt/dxrt_drv_cdev.o /home/atg/m1/dx_rt_npu_linux_driver/modules/rt/dxrt_drv_message.o /home/atg/m1/dx_rt_npu_linux_driver/modules/rt/dxrt_drv_queue.o /home/atg/m1/dx_rt_npu_linux_driver/modules/rt/dxrt_sched.o /home/atg/m1/dx_rt_npu_linux_driver/modules/rt/dxrt_drv_dl.o

