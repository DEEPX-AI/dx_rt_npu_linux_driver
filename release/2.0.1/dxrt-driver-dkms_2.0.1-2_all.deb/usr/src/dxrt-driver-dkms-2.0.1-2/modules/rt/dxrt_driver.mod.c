#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x2c635209, "module_layout" },
	{ 0x37ce6741, "cdev_del" },
	{ 0x30a93ed, "kmalloc_caches" },
	{ 0x51b1c11d, "cdev_init" },
	{ 0xf9a482f9, "msleep" },
	{ 0x645da062, "dx_pcie_interrupt" },
	{ 0x9d9d70e6, "dx_sgdma_init" },
	{ 0x9b9ef2b1, "dx_pcie_get_request_queue" },
	{ 0x63be5207, "dx_pcie_get_init_completed" },
	{ 0xdf4fad68, "dx_pcie_get_driver_info" },
	{ 0x1ccbceca, "dx_pcie_set_init_completed" },
	{ 0x75e0fe, "dma_mmap_attrs" },
	{ 0x91193f38, "dx_pcie_notify_req_to_device" },
	{ 0x837b7b09, "__dynamic_pr_debug" },
	{ 0xdff7669f, "device_destroy" },
	{ 0xe8765b54, "dx_pcie_get_log_area" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x8134286, "dx_pcie_dequeue_event_response" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x46afdcba, "dma_free_attrs" },
	{ 0xdd64e639, "strscpy" },
	{ 0x71038ac7, "pv_ops" },
	{ 0x96375987, "dx_pcie_get_download_region" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6106b455, "dx_pcie_dequeue_response" },
	{ 0x4e28dccd, "dx_sgdma_write" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x4c9f47a5, "current_task" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xa0aa95d4, "kthread_stop" },
	{ 0x799c15a5, "dx_pcie_get_dev_num" },
	{ 0x98ff5b35, "dx_pcie_interrupt_event_wakeup" },
	{ 0x9f6c145f, "dx_pcie_get_download_size" },
	{ 0xe4cb9af1, "dx_pcie_interrupt_wakeup" },
	{ 0x9a3c9869, "dx_sgdma_read" },
	{ 0xfda406b8, "dx_pcie_get_dl_area" },
	{ 0xce11de54, "dma_alloc_attrs" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xcf2a881c, "device_create" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0xabac4112, "cdev_add" },
	{ 0x800473f, "__cond_resched" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x3d26254e, "dx_pcie_interrupt_clear" },
	{ 0xa916b694, "strnlen" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x2ec2012f, "dx_pcie_notify_msg_to_device" },
	{ 0x1000e51, "schedule" },
	{ 0x92997ed8, "_printk" },
	{ 0xb9e7429c, "memcpy_toio" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x269ac578, "dx_pcie_enqueue_event_response" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xaf88e69b, "kmem_cache_alloc_trace" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x2699c5f1, "dx_pcie_is_response_queue_empty" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0x39e7916b, "dx_pcie_clear_response_queue" },
	{ 0x37a0cba, "kfree" },
	{ 0xe1e7a493, "dx_pcie_get_booting_region" },
	{ 0x7d628444, "memcpy_fromio" },
	{ 0x3ee2b36d, "class_destroy" },
	{ 0x92540fbf, "finish_wait" },
	{ 0xd545a0fc, "dx_pcie_get_message_area" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xad0bf482, "dx_sgdma_deinit" },
	{ 0x9b0fb107, "__class_create" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
};

MODULE_INFO(depends, "dx_dma");


MODULE_INFO(srcversion, "79694311E563546691BC1B7");
